package com.example.reenawork

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
